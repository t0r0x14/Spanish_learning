import React, { useEffect, useState, useRef } from 'react';
import axios from 'axios';

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:5178';

function useSpeechRecognition(onResult) {
  const recognitionRef = useRef(null);
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;
    const r = new SpeechRecognition();
    r.lang = 'es-ES';
    r.interimResults = false;
    r.maxAlternatives = 1;
    r.onresult = (e) => {
      const text = Array.from(e.results).map(r => r[0].transcript).join('');
      onResult(text);
    };
    recognitionRef.current = r;
  }, []);
  return recognitionRef;
}

export default function Chat() {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: '¡Hola! Soy tu compañero para practicar español. ¿Sobre qué te gustaría hablar hoy?' }
  ]);
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [voiceMode, setVoiceMode] = useState(true);
  const [difficulty, setDifficulty] = useState('beginner');
  const recognitionRef = useSpeechRecognition((text) => {
    setInput(text);
    // Auto-send after recognition:
    handleSend(text);
  });

  // For TTS
  function speak(text) {
    if (!('speechSynthesis' in window)) return;
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = 'es-ES';
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utter);
  }

  async function handleSend(overrideText) {
    const content = overrideText !== undefined ? overrideText : input.trim();
    if (!content) return;
    const newMessages = [...messages, { role: 'user', content }];
    setMessages(newMessages);
    setInput('');
    // send to backend
    try {
      const resp = await axios.post(`${BACKEND_URL}/api/chat`, {
        messages: newMessages.map(m => ({ role: m.role, content: m.content })),
        difficulty,
        action: 'chat'
      }, { timeout: 120000 });
      const reply = resp.data.reply;
      const updated = [...newMessages, { role: 'assistant', content: reply }];
      setMessages(updated);
      if (voiceMode) speak(reply);
    } catch (err) {
      console.error(err);
      const errMsg = 'Error connecting to backend. ¿El servidor está corriendo?';
      setMessages(prev => [...prev, { role: 'assistant', content: errMsg }]);
    }
  }

  async function handleTranslate() {
    const lastAssistant = [...messages].reverse().find(m => m.role === 'assistant');
    if (!lastAssistant) return;
    try {
      const resp = await axios.post(`${BACKEND_URL}/api/chat`, {
        action: 'translate',
        lastAssistantMessage: lastAssistant.content
      }, { timeout: 120000 });
      const { translation, simplified } = resp.data;
      setMessages(prev => [...prev, { role: 'system', content: `English translation: ${translation}` }, { role: 'system', content: `Simplified Spanish: ${simplified}` }]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'system', content: 'Error translating message.' }]);
    }
  }

  function toggleRecording() {
    const r = recognitionRef.current;
    if (!r) {
      alert('Speech recognition not available in this browser.');
      return;
    }
    if (isRecording) {
      r.stop();
      setIsRecording(false);
    } else {
      r.lang = 'es-ES';
      r.start();
      setIsRecording(true);
    }
  }

  return (
    <div>
      <div className="flex gap-4 mb-4 items-center">
        <label className="flex items-center gap-2">
          <input type="checkbox" checked={voiceMode} onChange={(e) => setVoiceMode(e.target.checked)} />
          Voice mode (TTS)
        </label>
        <select value={difficulty} onChange={(e) => setDifficulty(e.target.value)} className="border rounded px-2 py-1">
          <option value="beginner">Beginner</option>
          <option value="intermediate">Intermediate</option>
          <option value="advanced">Advanced</option>
        </select>
        <button className="ml-auto bg-sky-500 text-white px-3 py-1 rounded" onClick={() => { setMessages([{ role: 'assistant', content: '¡Hola! Soy tu compañero para practicar español. ¿Sobre qué te gustaría hablar hoy?' }]); }}>
          Reset
        </button>
      </div>

      <div className="border rounded p-4 h-80 overflow-y-auto mb-4 bg-gray-50">
        {messages.map((m, i) => (
          <div key={i} className={`mb-3 ${m.role === 'assistant' ? '' : 'text-right'}`}>
            <div className={`inline-block p-3 rounded-lg ${m.role === 'assistant' ? 'bg-white shadow' : 'bg-blue-500 text-white'}`}>
              <div className="text-sm whitespace-pre-wrap">{m.content}</div>
            </div>
            <div className="text-xs mt-1 text-gray-400">{m.role}</div>
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <input className="flex-1 border rounded px-3 py-2" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Escribe en español..." />
        <button className="bg-green-600 text-white px-4 py-2 rounded" onClick={() => handleSend()}>Enviar</button>
        <button className={`px-3 py-2 rounded border ${isRecording ? 'bg-red-400 text-white' : ''}`} onClick={toggleRecording}>{isRecording ? 'Stop' : '🎤'}</button>
        <button className="px-3 py-2 rounded border" onClick={handleTranslate}>No entiendo (translate)</button>
      </div>
    </div>
  );
}
